import PocketBase from "pocketbase";

export const client = new PocketBase("http://127.0.0.1:8090")
